public class App {
    public static void main(String[] args) throws Exception {
        SkalaStockMarket skalaStockMarket = new SkalaStockMarket();
        skalaStockMarket.start();
    }
}
