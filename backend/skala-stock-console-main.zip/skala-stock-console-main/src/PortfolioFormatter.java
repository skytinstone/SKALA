/**
 * 포트폴리오 출력 형식을 정의하는 인터페이스입니다.
 */
public interface PortfolioFormatter {
    String format(Portfolio portfolio);
}